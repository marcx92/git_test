package ExerciciLletresRepetides;

public class Fase_1 {

	public static void main(String[] args) {
		 char [] myName = {'M', 'A', 'R', 'C', 'X', 'A', 'V', 'I', 'E', 'R'};
		 for (int i = 0; i < myName.length; i++) {
		      System.out.println(myName[i]);
		 }
	}
}

